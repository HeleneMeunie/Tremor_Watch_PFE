import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import App from './App.js';
import {Link}from "react-router-dom";


class Header extends React.Component
{
  render()
  {
    return (
        
        <div>
          <head>
        <meta charset="utf-8" />
  <link rel="icon" href="%PUBLIC_URL%/dev-logo.png" />
  <meta name="theme-color" content="#000000" />
  <title>CoderGuides</title>
        </head> 
        
      <nav class="navbar navbar-expand-sm bg-primary navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item active h-elem">
        
          <Link class="nav-link" style={{ color: 'inherit', textDecoration: 'inherit'}} to="/">Accueil</Link>
        </li>
        <li class="nav-item h-elem">
        <Link class="nav-link" style={{ color: 'inherit', textDecoration: 'inherit'}} to="/courbes-simples">Courbes simples</Link>
          
        </li>
        <li class="nav-item h-elem">
            <Link class="nav-link" style={{ color: 'inherit', textDecoration: 'inherit'}} to="/donut">Moyennes</Link>
          
        </li>
        <li class="nav-item h-elem">
            <Link class="nav-link" style={{ color: 'inherit', textDecoration: 'inherit'}} to="/score">Score</Link>
            
        </li>
        
      </ul>
    </nav>
        <h1 className="titre">Interface Tremor Watch</h1> 
        </div>
      
    )
  }
}
export default Header;
