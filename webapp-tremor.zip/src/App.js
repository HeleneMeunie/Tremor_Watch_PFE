/*Navigation between pages with react-router-dom*/
import './App.css';
import React from 'react';
import Header from './Header.js';
import Footer from './Footer.js';


import { BrowserRouter, Route, Switch } from 'react-router-dom';

import Home from './Home';
import Donut from './Donut';
import Score from './Score';
import Solo_courbes from'./Courbi'
class App extends React.Component  {
  

     
    render() { 
        
      return ( 
         
        <div>
          
          <BrowserRouter>
        <div>
          <Header />
            <Switch>
          

          <Route exact path="/">
            <Home />
           </Route>
          
             
          
             <Route path="/courbes-simples">
          <Solo_courbes />
           </Route>
          
             <Route path="/donut">
          <Donut />
           </Route>
          
             <Route path="/score">
          <Score />
           </Route>
             
           </Switch>
        </div> 
      </BrowserRouter>
          <Footer></Footer>
</div>
      ); 
    } 
}

export default App;
